package U5.U4_U5_Examen;

public interface Callejera {
    void amo_a_escucha();
}
